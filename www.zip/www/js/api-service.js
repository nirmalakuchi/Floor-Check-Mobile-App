﻿(function () {
    var sgtechdayModule = angular.module('starter.controllers');

    function apiService($http) {
        
        var BASE_URL = "http://sgtechday.azurewebsites.net/api/";
        //var BASE_URL = "http://localhost:55042/api/";

        var _apiService = {};

        _apiService.getMethod = function (url) {
            return $http.get(BASE_URL + url);
        };

        _apiService.getMethodWithParams = function (url, paramData) {
            $http.defaults.headers.common['Content-Type'] = 'application/javascript';
            $http.defaults.headers.common['Content-Type'] = 'application/json';
            if (window.localStorage["sgtechday-akey"]) {
                $http.defaults.headers.common.Authorization = 'Bearer ' + window.localStorage["sgtechday-akey"];
            }

            return $http.get(BASE_URL + url, { params: paramData });
        }

        _apiService.postMethod = function (url, data) {
            $http.defaults.headers.common['Content-Type'] = 'application/javascript';
            $http.defaults.headers.common['Content-Type'] = 'application/json';
            if (window.localStorage["sgtechday-akey"]) {
                $http.defaults.headers.common.Authorization = 'Bearer ' + window.localStorage["sgtechday-akey"];
            }
            
            if (data != null) {
                return $http({
                    method: 'POST',
                    url: BASE_URL + url,
                    data: data
                });
            }
            else {
                return $http({
                    method: 'POST',
                    url: BASE_URL + url
                });
            }
        }

        return _apiService;
    }

    sgtechdayModule.factory('apiService', apiService);

})();