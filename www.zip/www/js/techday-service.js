﻿(function () {
    var sgtechdayModule = angular.module('starter.controllers');

    let techdayService = function (apiService, $http) {
        var _techdayService = {};

        var userModel = {
            id: "",
            Username: "",
            FirstName: "",
            LastName: "",
            MiddleName: "",
            Password: "",
            IsQuizCompleted: "",
            QuizTime: "",
            Message: "",
            Error: ""
        };

        _techdayService.getQuizQuestions = function() {
            return apiService.postMethod('techday/GetQuizQuestions', null);
        }

        _techdayService.saveQuizResult = function (userQuizResult) {
            return apiService.postMethod('techday/SaveQuizResult', userQuizResult);
        }


        return _techdayService;
    }

    sgtechdayModule.factory('techdayService', techdayService);

})();