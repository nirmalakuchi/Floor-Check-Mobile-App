﻿(function () {
    var sgtechdayModule = angular.module('starter.controllers');

    let userService = function (apiService, $http) {
        var _userService = {};

        var userModel = {
            id: "",
            Username: "",
            FirstName: "",
            LastName: "",
            MiddleName: "",
            Password: "",
            IsQuizCompleted: false,
            QuizTime: "",
            Message: "",
            Error: ""
        };

        _userService.registerUser = function (username) {
            //let user = { Username: username, Password: password };
            let user = userModel;

            user.Username = username.split("@")[0];
            let usernameArr = user.Username.split(".");

            user.FirstName = usernameArr[0];

            if (usernameArr.length == 2) {
                user.LastName = usernameArr[1];
            }
            else if (usernameArr.length == 3) {
                user.MiddleName = usernameArr[1];
                user.LastName = usernameArr[2];
            }


            return apiService.postMethod('User/RegisterUser', user);
        }

        _userService.authenticateUser = function (username, password) {
            //let user = { Username: username, Password: password };
            let user = userModel;
            user.Username = username.split("@")[0];
            user.Password = password;

            return apiService.postMethod('User/AuthenticateUser', user);
        }

        _userService.setUserKey = function (userData) {
            $http.defaults.headers.common.Authorization = 'Bearer ' + userData.Message;
            window.localStorage["instakyc-akey"] = userData.Message;
            window.localStorage["instakyc-ukey"] = userData.id;
            window.localStorage["instakyc-uobj"] = JSON.stringify(userData);
        }

        _userService.getUserId = function () {
            return window.localStorage["instakyc-ukey"];
        }

        _userService.isAuthenticated = function () {
            return (window.localStorage["instakyc-ukey"] != null);
        }

        _userService.getLocalUser = function () {
            if (window.localStorage["instakyc-uobj"] == null)
                return null;
            var userObjStr = window.localStorage["instakyc-uobj"];
            return JSON.parse(userObjStr);
        }

        _userService.updateLocalUser = function (user) {
            window.localStorage["instakyc-uobj"] = JSON.stringify(user);
        }

        _userService.clearUserKeys = function () {
            window.localStorage.removeItem("instakyc-ukey");
            window.localStorage.removeItem("instakyc-uobj");
            window.localStorage.removeItem("instakyc-akey");

        }

        _userService.getMyBookings = function () {
            apiService.postMethod('')
        }

        return _userService;
    }

    sgtechdayModule.factory('userService', userService);

})();